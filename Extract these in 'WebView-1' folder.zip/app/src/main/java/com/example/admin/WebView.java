package com.example.admin;

import android.app.Activity;

public class WebView extends Activity {
}
